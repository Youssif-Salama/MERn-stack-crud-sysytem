const show_data_table = document.querySelector(".show_data_table");
let employees = [];
let id = 1;
async function getAllEmployees(callback) {
    const result = await fetch("http://localhost:10000/api/v1/employee");
    const data = await result.json();
    employees = data.data.employees;
    callback();
}

function handleGetAllEmployees() {
    show_data_table.innerHTML = "";
    show_data_table.innerHTML = `<tr class="table_head">
    <td>name</td>
    <td>email</td>
    <td>address</td>
    <td>phone</td>
    <td>actions</td>
</tr>`
    employees.map(employee => {
        const inner = `
        <tr class="table_data" id="${employee._id}">
        <td>${employee.name}</td>
        <td>${employee.email}</td>
        <td>${employee.country}</td>
        <td>${employee.phone}</td>
        <td class="action_row">
            <i class="fa-solid fa-pencil update_one" style="color:yellow;padding:1px;margin:5px;"></i>
            <i class="fa-solid fa-trash delete_one" style="color: red;padding:1px;margin:5px;"></i>
        </td>
    </tr>
        `;
        show_data_table.innerHTML += inner;
    })
}
const update_employee = document.querySelector(".update_employee")
const add_employee = document.querySelector(".add_employee");
update_employee.style.display = "none";
function observe_update_delete() {
    show_data_table.addEventListener("click", (e) => {
        const target = e.target.closest(".table_data");

        if (target) {
            const _id = target.getAttribute("id");

            if (e.target.classList.contains("update_one")) {
                add_employee.style.display = "none";
                update_employee.style.display = "block";
                update_employee.style.color = "var(--color_1)";
                update_employee.style.background = "yellow";
                id = _id;
            } else if (e.target.classList.contains("delete_one")) {
                id = _id;
                deleteEmployee()
            }
        }
    });
}


async function call() {
    await getAllEmployees(handleGetAllEmployees);
    observe_update_delete()
}
call()
// add ne employee
const nameInput = document.querySelector("input.name");
const emailInput = document.querySelector("input.email");
const countryInput = document.querySelector("input.country");
const phoneInput = document.querySelector("input.phone");

async function addNewEmployee() {
    await fetch("http://localhost:10000/api/v1/employee/", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: nameInput.value,
            email: emailInput.value,
            country: countryInput.value,
            phone: phoneInput.value
        })
    })
        .then(() => {
            getAllEmployees(handleGetAllEmployees);
        })
}
// delete all employees
async function deleteAllEmployees() {
    await fetch("http://localhost:10000/api/v1/employee/", {
        method: "DELETE"
    })
        .then(() => {
            getAllEmployees(handleGetAllEmployees);
        })
}
// update employee data
async function updateEmployee() {
    await fetch(`http://localhost:10000/api/v1/employee/update/:${id}`, {
        method: "PUT",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: nameInput.value,
            email: emailInput.value,
            country: countryInput.value,
            phone: phoneInput.value
        })
    })
        .then(() => {
            getAllEmployees(handleGetAllEmployees);
        })
}
// delete_one
async function deleteEmployee() {
    console.log(id)
    await fetch(`http://localhost:10000/api/v1/employee/delete/${id}`, {
        method: "DELETE"
    })
        .then(() => {
            getAllEmployees(handleGetAllEmployees);
        })
}

add_employee.addEventListener("click", _ => {
    addNewEmployee();
})
update_employee.addEventListener("click", _ => {
    updateEmployee();
})