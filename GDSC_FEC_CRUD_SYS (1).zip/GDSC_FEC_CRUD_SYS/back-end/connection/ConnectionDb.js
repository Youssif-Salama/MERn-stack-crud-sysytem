import mongoose from "mongoose";
import env from "dotenv";
env.config();
export const connectionDb = mongoose.connect(process.env.CONNECTION_URL + process.env.DATABASE_NAME);