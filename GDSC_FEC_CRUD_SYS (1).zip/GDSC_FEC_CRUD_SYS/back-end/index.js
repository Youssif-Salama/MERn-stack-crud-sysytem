import { bootstrap } from "./bootstrap/bootstrap.js";

bootstrap();