import { Router } from "express";
import { employeeRouter } from "../src/modules/employee/routers/employee.routes.js";

const v1Router = Router();
v1Router.use("/employee", employeeRouter)
export { v1Router }