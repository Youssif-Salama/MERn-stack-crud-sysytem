import express from "express";
import cors from "cors";
import { connectionDb } from "../connection/ConnectionDb.js";
import { v1Router } from "../routers/v1.router.js";
export function bootstrap() {
    const server = express();

    server.use(express.json());
    server.use(cors())
    server.use("/api/v1", v1Router);

    const port = 10000;

    connectionDb.then(() => {
        console.log("connection done !");
        server.use((error, req, res, next) => {
            const { message, status } = error;
            res.status(status || 500).json({ message })
        })
        server.listen(port, () => {
            console.log(`server is listening on port: ${port}`);
        })
    }).catch((error) => {
        console.error(error);
    })
}