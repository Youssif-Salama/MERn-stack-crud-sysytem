import { Router } from "express";
import { addNewUser, deleteAll, deleteOne, getAllEmployees, updateEmployee } from "../controllers/employee.controllers.js";

const employeeRouter = Router();
employeeRouter.post("/", addNewUser);
employeeRouter.put("/update/:employeeId", updateEmployee);
employeeRouter.delete("/delete/:employeeId", deleteOne);
employeeRouter.delete("/", deleteAll);
employeeRouter.get("/", getAllEmployees);
export { employeeRouter };