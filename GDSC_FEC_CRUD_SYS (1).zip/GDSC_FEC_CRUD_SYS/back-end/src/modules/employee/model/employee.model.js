import mongoose from "mongoose";

const employeeSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    country: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    }
})

export const Employee = mongoose.model("employee", employeeSchema);