import { appError, catchError } from "../../../../utils/error.handler.js";
import { Employee } from "../model/employee.model.js";

export const addNewUser = catchError(async (req, res) => {
    const addUser = await Employee.create(req.body);
    if (!addUser) throw new appError("failed to add user", 400);
    res.status(201).json(
        {
            message: "success", status: "OK",
            employee: addUser
        }
    );
})

export const updateEmployee = catchError(async (req, res) => {
    const employeeId = (req.params.employeeId).split(":").join("");
    const update = await Employee.findByIdAndUpdate(employeeId, req.body, { new: true });
    if (!update) throw new appError("failed to update user", 400);
    res.status(200).json(
        {
            message: "success", status: "OK",
            employee: update
        }
    );
});

export const deleteOne = catchError(async (req, res) => {
    const employeeId = (req.params.employeeId).split(":").join("");
    const del = await Employee.deleteOne({ _id: employeeId });
    if (!del) throw new appError("failed to delete employee", 400);
    else {
        const result = await Employee.find();
        if (!result) throw new appError("failed to get all users");
        res.status(200).json({ success: true, message: "Success", data: { employees: result } });
    }
})

export const deleteAll = catchError(async (req, res) => {
    const del = await Employee.deleteMany()
    if (!del) throw new appError("failed to delete employees", 400);
    res.status(200).json({ message: "success" });
})

export const getAllEmployees = catchError(async (req, res) => {
    const result = await Employee.find();
    if (!result) throw new appError("failed to get all users");
    res.status(200).json({ success: true, message: "Success", data: { employees: result } });
})